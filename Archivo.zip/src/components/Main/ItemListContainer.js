const ItemListContainer = ({ greetings }) => {
  return <h1 className="display-1 mt-5 box-greetings">{greetings}</h1>;
};

export default ItemListContainer;
