import Logo from "../../../src/images/logo.png";

const Brand = () => {
  return <img src={Logo} alt="logo" />;
};

export default Brand;
