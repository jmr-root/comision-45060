const NavBar = () => {
  return (
    <ul className="d-flex navigation">
      <li>
        <a href="./">Categoria 1</a>
      </li>
      <li>
        <a href="./">Categoria 2</a>
      </li>
      <li>
        <a href="./">Categoria 3</a>
      </li>
      <li>
        <a href="./">Categoria 4</a>
      </li>
    </ul>
  );
};

export default NavBar;
